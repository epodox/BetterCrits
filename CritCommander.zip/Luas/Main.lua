-- Register the Namespace
local CritCommander, NS = ...


-- Starts listening for crits.
NS.Register()


-- Main.lua end.
SendOutput("Crit Commander - Main.lua has been loaded.")